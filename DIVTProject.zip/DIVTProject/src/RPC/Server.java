package RPC;

public class Server {

}
